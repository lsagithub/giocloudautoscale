<?php

//vm config
//zone id notsure get from template list
define('ZONE_ID','e2a1afc9-ea21-4113-b1b8-3daa8d5b1f23');

//service offering id from acp account id
define('SVC_ID','1a03ba94-726d-4238-9ec3-84ad26c84388');

//template id
define('TEMPLATE_ID','e2a1afc9-ea21-4113-b1b8-3daa8d5b1f23');
//network id
define('NETWORK_ID','141e854c-1846-4b22-b548-a760bd1208fa');
//region Asia/Bangkok
define('REGION','bangkok');
//load balancer id 
define('LB_ID','20a3558f-a768-408a-bec7-bdc84a0b0e37');

//db config
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'autoscale');

?>
